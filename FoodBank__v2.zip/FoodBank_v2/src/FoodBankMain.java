
public class FoodBankMain {
	public static void main(String[] args) {
		new FoodBankUI();
	}
}
