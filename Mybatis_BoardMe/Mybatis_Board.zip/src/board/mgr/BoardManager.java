package board.mgr;

import java.util.ArrayList;

import board.dao.BoardDAO;
import board.vo.Board;

public class BoardManager {
	
	private BoardDAO dao = new BoardDAO();
	
	//�� ����
	public boolean insertBoard(Board board) {
		 int count=dao.insertBoard(board);
	
		 if (count > 0) {
			 return true;
		}
		 return false;
	}
	//�� ���
	public ArrayList<Board> listBoard() {
		 ArrayList<Board> list = dao.listBoard();
		 return list;
	}
	
	//1���� �� �а� ��ȸ�� ����
	public Board readBoard(int boardnum) {
		Board board =new Board();  
		board=dao.readBoard(boardnum);
		return board;
		
	}
	
	//1���� �ۻ���
	public boolean deleteBoard(int boardnum) {
		int count= dao.deleteBoard(boardnum);
		 if (count > 0) {
			 return true;
		}
		 return false;
	}

	//�� �˻�
	public ArrayList<Board> searchBoard(String word) {
		ArrayList<Board> list = dao.searchBoard(word);
		 return list;
	}
}
