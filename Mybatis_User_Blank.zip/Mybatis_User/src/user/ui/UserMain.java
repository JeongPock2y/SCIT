package user.ui;

public class UserMain {

	public static void main(String[] args) {
		UserUI ui = new UserUI();
	}

}
