package global.sesoc.vo;

public class Bicycle {
	private String type;
	
}
