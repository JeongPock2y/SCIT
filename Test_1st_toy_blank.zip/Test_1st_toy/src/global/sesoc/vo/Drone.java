package global.sesoc.vo;

public class Drone {
	private int wingCount;
	

	
}
