package global.sesoc.vo;

public class GameConsole {

	private boolean isPortable;
	
}
