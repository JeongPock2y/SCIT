package global.sesoc.vo;

public class Toy {
	private String serialNum;
	private String name;
	private int price;
	
}
