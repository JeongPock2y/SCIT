package Tour.ui;

public class TourMain {

	public static void main(String[] args) {
		new TourUI();
	}

}
